# BBMS_JAVA
Blood Bank Management System - JAVA


A desktop-based application, designed to store, process, retrieve
and analyze information about donors. The basic building aim is
to provide blood donation service


Language: JAVA
IDE/Editor: Sublime Text + Brackets
Server: MySQL
OS: Windows 10
