package com.arnabb.bbms;

import com.arnabb.bbms.Home.Homee;

public class Start {
	public static void main(String args[]) throws Exception {
		Homee h = new Homee();
		h.setVisible(true);
	}
}