package com.arnabb.bbms.Home;//try / gui 1 / homee

import com.arnabb.bbms.Donor.Donor;
import com.arnabb.bbms.Login.Login;
import com.arnabb.bbms.Search.SearchInfo;
import com.arnabb.bbms.Search.Stock;

import java.io.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.imageio.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.border.*;

public class Homee extends JFrame implements MouseListener, ActionListener {

    private JLabel title, title2, imgLab, background;
    private JButton b1, b2, b3, b4, b5, b6;
    private JPanel panel;
    private ImageIcon img;
    private Border normalBorder;
    private Border hoverBorder;

    public Homee() {
        super("BBMS : Welcome");
        this.setSize(700, 600);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        BufferedImage img = null;
        try {
            img = ImageIO.read(new File(
                    "C:\\Users\\talkt\\Downloads\\Blood Bank Management System FINAL\\Blood Bank Management System FINAL\\blood bank sample\\bloodbank-management-sys-master\\assets\\final fr.png"));
            background = new JLabel(new ImageIcon(img));
            background.setBounds(0, 0, 700, 600);
        } catch (IOException e) {
        }

        title = new JLabel("Blood Donation Management System");
        title.setBounds(70, 60, 700, 150);
        title.setFont(new Font("Arial", Font.BOLD, 30));
        title.setForeground(new Color(234, 67, 53)); // Set to match button color
        panel.add(title);

        title2 = new JLabel("Donate Blood, Save lives");
        title2.setBounds(232, 140, 400, 80);
        title2.setFont(new Font("Arial", Font.BOLD + Font.ITALIC, 20));
        title2.setForeground(new Color(234, 67, 53)); // Set to match button color
        panel.add(title2);

        normalBorder = BorderFactory.createLineBorder(new Color(234, 67, 53), 1);
        hoverBorder = BorderFactory.createLineBorder(new Color(234, 67, 53), 3);

        b1 = createButton("Administration", 250, 270);
        panel.add(b1);

        b2 = createButton("Donor Login", 250, 320);
        panel.add(b2);

        b3 = createButton("Search", 250, 370);
        panel.add(b3);

        b4 = createButton("Stock Available", 250, 420);
        panel.add(b4);

        b6 = createButton("Exit", 250, 470);
        panel.add(b6);

        panel.add(background);
        this.add(panel);
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 35);
        button.setBackground(new Color(234, 67, 53));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(true);
        button.setBorder(normalBorder);
        button.addMouseListener(this);
        button.addActionListener(this);
        return button;
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        JButton source = (JButton) me.getSource();
        source.setBorder(hoverBorder);
    }

    @Override
    public void mouseExited(MouseEvent me) {
        JButton source = (JButton) me.getSource();
        source.setBorder(normalBorder);
    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mousePressed(MouseEvent me) {
    }

    @Override
    public void mouseClicked(MouseEvent me) {
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String elementText = ae.getActionCommand();

        if (elementText.equals(b1.getText())) {
            try {
                Login l = new Login();
                l.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (elementText.equals(b2.getText())) {
            try {
                Donor d = new Donor();
                d.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (elementText.equals(b3.getText())) {
            try {
                SearchInfo si = new SearchInfo();
                si.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (elementText.equals(b4.getText())) {
            try {
                Stock st = new Stock();
                st.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (elementText.equals(b6.getText())) {
            System.exit(0);
        }
    }

}