package com.arnabb.bbms.Donor;

import com.arnabb.bbms.Admin.AdminPanel;

import java.io.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.imageio.*;
import java.awt.image.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class DeleteDonor extends JFrame implements ActionListener {
    private JLabel background, numberLabel, idLabel;
    private JTextField numberTF, tryTF;
    private JButton buttonBack, buttonLogout, buttonDelete, buttonRefresh;
    private JPanel panel;
    private JTable table;
    private DefaultTableModel tableModel;

    public DeleteDonor(String aID) {
        super("Eliminate Donor");
        this.setSize(700, 600);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        BufferedImage img = null;
        try {
            img = ImageIO.read(new File(
                    "C:\\Users\\talkt\\Downloads\\Blood Bank Management System FINAL\\Blood Bank Management System FINAL\\blood bank sample\\bloodbank-management-sys-master\\assets\\final fr.png"));
            background = new JLabel(new ImageIcon(img));
            background.setBounds(0, 0, 700, 600);
        } catch (IOException e) {
        }

        numberLabel = new JLabel("Enter Donor ID ");
        numberLabel.setBounds(100, 400, 150, 30);
        numberLabel.setForeground(Color.white);
        panel.add(numberLabel);

        numberTF = new JTextField();
        numberTF.setBounds(250, 400, 150, 30);
        panel.add(numberTF);

        idLabel = new JLabel(aID);
        idLabel.setVisible(false);
        panel.add(idLabel);

        buttonBack = createButton("Back", 200, 500);
        panel.add(buttonBack);

        buttonDelete = createButton("Delete", 420, 400);
        panel.add(buttonDelete);

        buttonRefresh = createButton("Refresh", 400, 500);
        panel.add(buttonRefresh);

        this.table = new JTable();
        Object[] column = { "Donor ID", "Name", "Blood Group", "City", "Contact", "Mail" };
        this.tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(column);
        this.table.setModel(tableModel);
        table.setBackground(Color.WHITE);
        table.setRowHeight(30);

        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(50, 20, 600, 250);
        this.add(pane);
        panel.add(pane);

        showData();

        panel.add(background);

        this.add(panel);
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 100, 35);
        button.setBackground(new Color(234, 67, 53));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(true);

        button.addActionListener(this);
        return button;
    }

    public void actionPerformed(ActionEvent ae) {
        String buttonClicked = ae.getActionCommand();

        if (buttonClicked.equals(buttonBack.getText())) {
            String id = idLabel.getText();

            try {
                AdminPanel ah = new AdminPanel(id);
                ah.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (buttonClicked.equals(buttonDelete.getText())) {
            deleteFromDB1();
            deleteFromDB2();
            deleteFromDB3();
            deleteFromDB4();
            deleteFromDB5();
        } else if (buttonClicked.equals(buttonRefresh.getText())) {
            String id = idLabel.getText();

            try {
                DeleteDonor dd = new DeleteDonor(id);
                dd.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void deleteFromDB1() {
        String query = "DELETE from donor_info where DonorID =" + numberTF.getText() + ";";
        System.out.println(query);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d_reg", "root",
                    "BlueKiaSportage616-");
            Statement stm = con.createStatement();
            stm.execute(query);
            stm.close();
            con.close();

        } catch (Exception ex) {
            System.out.println("Exception : " + ex.getMessage());
        }
    }

    public void deleteFromDB2() {
        String query = "DELETE from donor_info where DonorID =" + numberTF.getText() + ";";
        System.out.println(query);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d_reg", "root",
                    "BlueKiaSportage616-");
            Statement stm = con.createStatement();
            stm.execute(query);
            stm.close();
            con.close();

        } catch (Exception ex) {
            System.out.println("Exception : " + ex.getMessage());
        }
    }

    public void deleteFromDB3() {
        String query = "DELETE from donor_info where DonorID =" + numberTF.getText() + ";";
        System.out.println(query);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d_reg", "root",
                    "BlueKiaSportage616-");
            Statement stm = con.createStatement();
            stm.execute(query);
            stm.close();
            con.close();

        } catch (Exception ex) {
            System.out.println("Exception : " + ex.getMessage());
        }
    }

    public void deleteFromDB4() {
        String query = "DELETE from donor_info where DonorID =" + numberTF.getText() + ";";
        System.out.println(query);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d_reg", "root",
                    "BlueKiaSportage616-");
            Statement stm = con.createStatement();
            stm.execute(query);
            stm.close();
            con.close();

        } catch (Exception ex) {
            System.out.println("Exception : " + ex.getMessage());
        }
    }

    public void deleteFromDB5() {
        String query = "DELETE from donor_info where DonorID =" + numberTF.getText() + ";";
        System.out.println(query);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d_reg", "root",
                    "BlueKiaSportage616-");
            Statement stm = con.createStatement();
            stm.execute(query);
            stm.close();
            con.close();

        } catch (Exception ex) {
            System.out.println("Exception : " + ex.getMessage());
        }
    }

    public void showData() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d_reg", "root",
                    "BlueKiaSportage616-");
            Statement stm = con.createStatement();
            String query = "SELECT DonorID, Name, BloodGroup, City, Contact, Email FROM donor_info;";

            ResultSet result = stm.executeQuery(query);

            while (result.next()) {

                Object[] rows = { result.getString(1), result.getString(2), result.getString(3), result.getString(4),
                        result.getString(5), result.getString(6) };

                this.tableModel.addRow(rows);
            }
            this.table.setModel(tableModel);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Something wrong!");
        }
    }
}
